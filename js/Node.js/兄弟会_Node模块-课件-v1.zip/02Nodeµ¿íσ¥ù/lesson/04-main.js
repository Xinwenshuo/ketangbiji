//导入模块
const circle = require("./my-modules/circle.js");
const squareClass = require("./my-modules/square.js");
const square = new squareClass(10);


//计算圆的面积和周长
console.log("圆的的面积："+circle.area(4));
console.log("圆的的周长："+circle.circumference(4));


//计算正方形的面积和周长
//var squareObj = new square(10);
console.log("正方形的面积："+square.area());
console.log("正方形的周长："+square.circumference());