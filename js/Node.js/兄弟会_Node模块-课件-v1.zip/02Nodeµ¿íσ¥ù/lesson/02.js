// 加载模块

// 加载核心模块
const http = require("http");

// 第三方的模块
const randomatic = require("randomatic");
console.log(randomatic("*", 20));

//自定义的模块 require 会判断 模块名 前面有没有 "./"  "../"  "/"
const aModule = require("./02-module.js");
//console.log(a);
console.log(aModule.a);

