//console.log(global);


// var 声明的全局变量  等同于  全局对象的属性
// username 不是全局变量， 在模块的作用域
var username = "Jack";

console.log(username);
console.log(global.username);

