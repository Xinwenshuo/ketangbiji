module.exports = function(){
    console.log("test.js");
}