module.exports = function(){
    console.log("index.js");
}