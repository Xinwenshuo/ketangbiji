//每个独立的文件都是模块  有自己的作用域
//console.log("老子是模块");
var a = 100;

exports.a = a;