//自定义模块
module.exports = {
    user: "丽丽",
    tag: 1001
}

//导出
module.exports = function(){
    console.log("模块2");
}

//导出 类(构造函数)
module.exports = class User{

}

// exports = {
//     a: 100
// };

/*
* module.exports
* const exports = module.exports
*
* a = {} //对象
* b = a; //b a 指向一个对象
* b.username = "" //a也会添加属性
* b = []  //把b换了指向
* */