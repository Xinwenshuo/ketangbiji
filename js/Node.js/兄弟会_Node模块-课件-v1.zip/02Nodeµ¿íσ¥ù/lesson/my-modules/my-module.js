//自定义模块
let username = "Jim";
let userInfo = {age:100, name:"丽丽"};


//导出或者暴露   内容
exports.username = username;
exports.userObj = userInfo;
exports.userage = 100;
exports.getInfo = function(){
    console.log(username, userInfo);
}

module.exports.address = "北京";

console.log(module.exports === exports);



