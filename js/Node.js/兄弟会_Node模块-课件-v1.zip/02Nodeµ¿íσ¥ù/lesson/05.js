//导入第三方 模块
const randomatic = require("randomatic");

//导入自定义模块  -- 文件模块
/*
* 文件不指定后缀，  优先加载my-module , 没有加载 my-module.js  , 还没有加载 my-module.json, 还没有  my-module.node
* */
const myModule = require("./my-modules2/my-module");

console.log(myModule);


// 导入自定义模块， -- 目录作为模块
/**
 *  如果目录中有 package.json 并且指定main， 一指定文件为模块的入口
 *  没指定或者没有package.json,  默认加载index.js,
 *  没有index.js 尝试加载 index.node
 * */
const testModule = require("./testModule");

testModule();


require("express");