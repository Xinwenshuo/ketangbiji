// 引入 各种模块
const myModule = require ("./my-modules/my-module.js");
const myModule2 = require("./my-modules/my-module2.js");

console.log(myModule);
console.log(myModule.username);
console.log(myModule.userObj);
console.log(myModule.userage);

myModule.getInfo();

console.log(myModule.address);


//console.log(myModule2.user);
//console.log(myModule2.tag);
new myModule2();