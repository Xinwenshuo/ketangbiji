//导入模块
const express = require('express');

//创建应用
const app = express();

/***
 * get /products  查看商品
 * get /products/1313123    查看具体的商品
 * get /products/13121112/comment  查看某商品的平路
 * post /products   添加商品
 * */

app.use('/products', require('./products-router'));

//监听
app.listen(3000, () => {
    console.log('http server is running on port 3000');
})