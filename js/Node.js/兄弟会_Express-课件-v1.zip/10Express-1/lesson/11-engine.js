//导入模块
const express = require('express');

//创建应用
const app = express();


//重新定义模板引擎
app.engine('html', require('ejs').__express);


//设置模板所在的目录
app.set('views', './temps');
//设置使用的模板引擎
app.set('view engine', 'html');

//路由
app.get('/', (req, res) => {
    res.render('index', {title:"Express模板引擎", content:'床亲故恶搞'})
})

//设置监听
app.listen(4000, () => {
    console.log('http服务运行中 端口:4000');
})