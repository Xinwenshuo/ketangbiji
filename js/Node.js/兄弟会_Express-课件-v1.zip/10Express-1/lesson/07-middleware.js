//导入模块
const express = require('express');

//创建应用
const app = express();

//中间件
app.use((req, res, next) => {
    console.log("所有的请求都要经过我：url: "+req.originalUrl);
    next();
});

app.use('/posts/:id', (req, res, next) => {
   console.log("我是中间件-孙悟空 "+req.originalUrl);
   next();
});

app.use('/posts/:id', (req, res, next) => {
    console.log('我是中间件-猪八戒');
    next();
}, (req, res, next) => {
    console.log('我是中间件-沙悟净');
    next();
})

app.get('/posts/:id', (req, res, next) => {
    console.log('get1');
    if (req.params.id == 0) {
        next('route');
    } else {
        next();
    }
}, (req, res, next) => {
    console.log('get2');
    next();
}, (req, res, next) => {
    console.log('get3');
    next();
});

app.get('/posts/:id', (req, res, next) => {
    console.log('我是中间件-唐僧');
    next();
});

app.use((req, res, next)=>{
    console.log('我是中间件-玉皇大帝');
    next();
})


app.get('/posts/:id', (req, res) => {
    console.log('最后的响应');
    res.send("posts 成功响应 id:"+req.params.id);
});


//监听
app.listen(4000, () => {
    console.log('http 服务正在运行， 端口:4000');
});


/*
const router = express.Router();
router.use()
router.METHOD;*/
