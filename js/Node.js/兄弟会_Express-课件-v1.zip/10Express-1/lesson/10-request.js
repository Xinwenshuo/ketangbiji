//导入模块
const express = require('express');

//创建应用
const app = express();

const router = express.Router();
router.get('/:id', (req, res) => {

   /* res.send(`
        baseUrl: ${req.baseUrl} <br>
        originalUrl: ${req.originalUrl} <br>
        protocol: ${req.protocol} <br>
        path: ${req.path} <br>
        hostname: ${req.hostname} <br>
        ip: ${req.ip} <br>
        xhr: ${req.xhr} <br>
        get方法: ${req.get('User-Agent')} <br>
    `);*/

     console.log(res.headersSent); //响应头还未发送
     //res.status(404).send("OK");
     //res.sendStatus(404); // res.status(404).send('not found)
     //res.download('./05-app.js', 'ddd.js');

     //res.jsonp({name:'lili', age:100});

     //res.redirect('/');
     res.send({name:'lili'});
     console.log(res.headersSent); //响应头已经发送

});

app.use('/posts', router);




//监听
app.listen(4000, () => {
    console.log('http server 运行中 端口:4000');
})