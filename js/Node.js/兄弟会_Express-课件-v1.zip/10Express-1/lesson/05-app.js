//导入模块
const express = require('express');

//创建应用
const app = express();

app.route('/comment')
    .get((req, res) => {
        res.send('查看评论');
    })
    .post((req, res) => {
        res.send('添加评论');
    })
    .put((req, res) => {
        res.send('修改评论')
    })
    .delete((req, res) => {
        res.send('删除评论')
    })

//监听
app.listen(3000, () => {
    console.log('http server is running on port 3000');
})