//导入模块
const express = require('express');

//创建express实例
const app = express();

//设置路由
/*app.get('/ab?c', (req, res) => {
    res.send('<h1>你好，成功请求</h1>')
});*/

/*app.get('/ab+c', (req, res) => {
    res.send('<h1>你好，成功请求</h1>')
});*/
/*
app.get('/ab*c', (req, res) => {
    res.send('<h1>你好，成功请求</h1>')
});
*/

/*app.get(/\/a{2,3}$/, (req, res) => {
    res.send('OK');
})*/


app.get('/search', (req, res) => {
    console.log(req.query);

    res.send('哈哈哈');
});


app.get('/article/:id', (req, res) => {
    console.log(req.params.id);
    res.send('参数：'+req.params.id);
});

app.get('/article/:id/to/:pid', (req, res) => {
    res.send(req.params.id + ', ' + req.params.pid)
})


//监听
app.listen(8080, () => {
   console.log('http server is running on port 8080');
});