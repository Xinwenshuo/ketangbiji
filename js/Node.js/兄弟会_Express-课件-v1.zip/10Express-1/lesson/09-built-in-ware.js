//导入模块
const express = require('express');

//创建应用
const app = express();


app.post('/article', express.urlencoded({extended: false}),(req, res) => {
   res.send(`post响应： title:${req.body.title}, author:${req.body.author}`);
});

//监听
app.listen(4000, () => {
    console.log('http 服务正在运行 端口:4000');
})