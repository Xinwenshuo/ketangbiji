//导入 模块
const express = require('express');

//创建express实例
const app = express();


app.all('/', (res, req, next) => {
    console.log('我也被执行了');
   // req.send('哈哈哈，都被我截了');
    next(); //下一个中间件
});

//路由
app.get('/', (req, res) => {
    res.send('网站首页');
});

app.get('/news', (req, res) => {
    res.send('新闻列表');
});

app.get('/news/detail', (req, res) => {
    res.send('新闻详情');
});

app.post('/', (req, res) => {
    res.send('这次使用的是post请求');
});

app.put('/', (req, res) => {
    res.send('这次使用的是put请求');
});

app.delete('/', (req, res) => {
    res.send('这次使用的是delete请求');
});




//监听
app.listen(8080, () => {
    console.log('http server is running on port 8080');
})