//导入模块
const express = require('express');
//const http = require('http');

//创建express 实例
const app = express();

//托管静态资源 中间件
app.use(express.static('../htdocs'));
//app.use('/site',express.static('../htdocs'));
//app.use(express.static('../lesson'));

//express的路由
app.get('/index', (req, res) => {
    res.send('Hello World 你好 世界');
});

//监听
app.listen(8080, () => {
    console.log('http server is running on port 8080');
})

/*http.createServer(app).listen(8080, () => {
    console.log('http server is running on port 8080');
})*/
