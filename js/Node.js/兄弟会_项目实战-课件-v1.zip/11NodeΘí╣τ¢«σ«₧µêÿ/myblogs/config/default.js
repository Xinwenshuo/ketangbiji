module.exports = {
    port: 3000, // 项目运行端口
    mongodb: 'mongodb://localhost:27017/xdlblog',
    session: {
        secret: 'xdlblog',
        key: 'xdlblog',
        maxAge:2592000000
    }
};