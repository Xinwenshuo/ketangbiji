/**
 * 留言的模型设计
 * */
const mongoose = require('mongoose');
const objectIdToTimestamp = require('objectid-to-timestamp');
const moment = require('moment');


//创建Schema
const CommentsScheam = new mongoose.Schema({
    userId: {type: mongoose.Schema.Types.ObjectId, ref:'users'},
    postId: {type: mongoose.Schema.Types.ObjectId},
    content: {type: String, required: [true, '留言内容不能为空']}
}, {
    collection: 'comments'
});

CommentsScheam.plugin(function(schema){
    schema.post('find', function(result){
        result.forEach(function(item){
            item.created_at = moment(objectIdToTimestamp(item._id)).format('YYYY-MM-DD HH:mm');
        })

    })

})

//创建模型
const CommentsModel = mongoose.model('comments', CommentsScheam);



//导出接口
module.exports = {
    //添加留言
    create(commentData) {
        const comment = new CommentsModel(commentData);
        return comment.save();
    },

    // 根据文章ID 显示留言
    getComments(postId) {
        return CommentsModel
            .find({postId: postId})
            .populate('userId')
            .sort({_id: -1})
            .exec()
    },

    //根据文章ID 返回留言的数量
    getCommentsCount(postId) {
        return CommentsModel.count({postId: postId}).exec()
    },

    //根据ID删除 留言
    deleteCommentById(commentId) {
       return CommentsModel.deleteOne({_id: commentId}).exec()
    },

    //根据 postId 删除留言
    deleteCommentByPostId(postId) {
        return CommentsModel.deleteMany({postId: postId}).exec();
    }
}