/**
 *  用户集合 的模型
 * */

const mongoose = require('mongoose');
const sha1 = require('sha1'); //用于密码加密
require('../lib/mongo');

//定义Schema
const UsersSchema = new mongoose.Schema({
    username: {type: String, required: [true, '用户名不能为空'], minlength:[2, '用户名最少2个字符'], maxlength:[12, '用户名不能超过10个字符'], unique:[true, '用户名已经被占用'], index:true},
    password: {type: String, required: [true, '密码不能为空']},
    avatar: {type:String},
    sex: {type:String, enum:{values: ['m', 'w', 'e'], message:'性别不能乱写'}},
    bio: {stype: String}
}, {autoIndex: true, collection: 'users'});

//创建模型
const UsersModel = mongoose.model('users', UsersSchema);


//导出
module.exports = {
    create(user) {
        //验证 密码的字符至少6个， 两次密码一致性
        if (user.password.length < 6) {
            return new Promise((resolve, reject) => {
                reject('自定义错误: password: 密码长度至少6位');
            })
        }

        //验证密码一致
        if (user.password !== user.repassword) {
            return new Promise((resolve, reject) => {
                reject('自定义错误: repassword: 两次密码不一致');
            })
        }

        //密码加密
        user.password = sha1(user.password);
        delete user.repassword; //删除确认密码

        let userInstance = new UsersModel(user);
        return userInstance.save();
    },

    findOneByName(username) {
        return UsersModel.findOne({username: username}).exec()
    }
}