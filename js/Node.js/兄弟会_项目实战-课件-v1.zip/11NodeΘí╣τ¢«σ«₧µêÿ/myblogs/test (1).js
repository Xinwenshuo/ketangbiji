const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/testDB');
const conn = mongoose.connection;

conn.on('open', () => {
    console.log('mongodb连接成功');
});

conn.on('error', (err) => {
    throw err;
});


const InfosSchema = new mongoose.Schema({
    name: {type:String},
    count: {type: Number}
});

InfosSchema.plugin(function(schema) {
    schema.post('find', function(result){
        console.log('我先');
        return Promise.all( result.map(function(item){
            /*item._doc.tag = "傻逼";
            return setTimeout(function(){
                item._doc.ddd = '弟弟弟弟';
                return item;
            })*/

            //return item;

            return new Promise(function(resolve, reject){
                setTimeout(function(){
                    resolve();
                }, 1000)
            }).then(function(){
                item._doc.pass = "你们是傻逼";
                return item;
            })
        }));


     /*  return result.map(function(item){
           item._doc.tag = "傻逼";
           return item;
       });*/

        //return [{_doc: {name: '你好'}}, {_doc:{name:'哈哈哈'}}];

       /* return Promise.all(result.map(function(item){
            item.tag = '大傻逼';
            return item;
        }))*/
    })
})

const InfosModel = mongoose.model('infos', InfosSchema);







InfosModel.count({name:'lili'}).exec().then(function(result){
   console.log(result);
}).catch(function(err){
    console.error(err);
})



/*
const info = new InfosModel({
    name:"ll",
    count:1
});

info.save();*/
/*
function demo() {
    return InfosModel.update({name:'lili'}, {$inc: {pv: 1}}).exec();
}
demo().then( function(result){
    console.log(result);
})
*/

/*
const postModel = require('./models/posts');

postModel.incPv().then((result) = {

});*/

