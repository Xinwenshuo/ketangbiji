const express = require('express');
const router =express.Router();


// GET /logout 退出登陆
router.get('/', (req, res) => {
    //清空session
    req.session.user = null;
    //通知信息
    req.flash('success', '成功退出登陆');
    //跳转
    res.redirect('/');
});

module.exports = router;