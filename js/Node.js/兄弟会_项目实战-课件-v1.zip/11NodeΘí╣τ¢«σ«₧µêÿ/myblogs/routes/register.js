const express = require('express');
const path = require('path');
const router = express.Router();
const usersModel = require('../models/users');
const checkNotLogin = require('../middlewares/check').checkNotLogin;

//GET  /register   注册页面
router.get('/', checkNotLogin,  (req, res) => {

    //渲染注册页面
    res.render('register');
});


//Post  /register 执行注册
router.post('/', checkNotLogin, (req, res) => {
    //获取表单中的数据
    let user = {
        username: req.fields.username,
        password: req.fields.password,
        repassword: req.fields.repassword,
        sex: req.fields.sex,
        avatar: req.files.avatar.path.split(path.sep).pop(),
        bio: req.fields.bio
    };

    //像集合中添加文档
    usersModel.create(user)
        .then((result) => {
            //添加通知信息
            req.flash('success', '注册成功');
            //跳转到登陆页
            res.redirect('/login');
        })
        .catch((err) => {
            let errMessage = err.toString().split(': ').pop();
            //添加通知信息
            req.flash('error', errMessage);
            //再次跳转到 注册页
            res.redirect('/register');
        })



});

module.exports = router;