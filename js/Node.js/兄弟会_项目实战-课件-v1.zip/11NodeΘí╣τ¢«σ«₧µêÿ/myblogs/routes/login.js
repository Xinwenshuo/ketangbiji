const express = require('express');
const router = express.Router();
const sha1 = require('sha1');
const usersModel = require('../models/users');
const checkNotLogin = require('../middlewares/check').checkNotLogin;

//GET /login  登陆页面
router.get('/', checkNotLogin, (req, res) => {
    res.render('login');
});

//POST /login  执行登陆
router.post('/', checkNotLogin, (req, res) => {
    console.log(req.session)

    //获取表单数据
    let username = req.fields.username;
    let password = req.fields.password;

    //console.log(username, password);
    //从集合中获取数据
    usersModel.findOneByName(username)
        .then((result) => {
            //判断用户是否存在
            if (!result) {
                //用户不存在
                req.flash('error', '用户名不存在');
                return res.redirect('back');
            }

            //判断密码是否匹配
            if (sha1(password) != result.password) {
                //密码错误
                req.flash('error', '密码错误');
                return res.redirect('back');
            }

            //登陆成功
            //把用户信息写入session
            delete result.password; //删除密码
            req.session.user = result;

            req.flash('success', '登陆成功');
            //跳转到首页
            res.redirect('/');

        })
        .catch((err) => {
            next(err);
        });
    //res.send('OK');
});

module.exports = router;