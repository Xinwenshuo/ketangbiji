const express = require('express');
const cookieParaser = require('cookie-parser');
const session = require('express-session');
const fileStore = require('session-file-store')(session);

const app = express();


app.set('views', 'views');
app.set('view engine', 'ejs');


//设置session中间件
app.use(session({
    name: 'demo',
    cookie:{path:'/'},
    secret:'my-demo',
    store: new fileStore(),
    resave: true,
    saveUninitialized: true
}));

//中间件
app.use(cookieParaser());


//路由
app.get('/', (req, res) => {

    console.log(req.session);

    //console.log(req.cookies);

    res.render('index', {cookieStr: req.headers.cookie, cookieObj: req.cookies});
});


app.get('/login', (req, res) => {

    //设置session
    req.session.users = {
        name:'lili',
        age:199
    };

    //设置cookie
    res.cookie('username', 'admin');
    res.cookie('userage', '100');
    res.cookie('usergrade', 'H5001', {
        path: '/articles',
        maxAge: 3600 * 24 * 7 * 1000
    });
    res.cookie('useraddress', '北京', {
        path: '/',
        domain: '127.0.0.1'
    });

    res.render('login')
});

app.get('/articles', (req, res) => {
    console.log(req.cookies);
    res.send('/articles');
});

app.get('/logout', (req, res) => {
    res.clearCookie('username');
    res.clearCookie('usergrade', {path:'/articles'});
    res.send('cookie 已经被删除');
})


app.listen(3000, () => {
    console.log('http server is running on port 3000');
})