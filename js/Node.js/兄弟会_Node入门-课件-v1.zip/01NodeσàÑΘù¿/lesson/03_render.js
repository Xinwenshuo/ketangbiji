//引入 模块
let http = require("http");
let fs = require("fs");

//创建HTTP服务
http.createServer(function(req, res){

    if (req.url === "/favicon.ico") {
        return false;
    }


    if (req.url === "/" || req.url === "/index.html") {
        //读取文件
        fs.readFile("./demo01.html", function(err, data){
            //设置响应头
            res.writeHead(200, {
                "Content-type":"text/html;charset=utf-8"
            });
            res.end(data);  //结束响应
        });
    } else if (req.url === "/detail.html") {
        //读取文件
        fs.readFile("./demo02.html", function(err, data){
            //设置响应头
            res.writeHead(200, {
                "Content-type":"text/html;charset=utf-8"
            });
            //结束响应
            res.end(data);
        })
    } else if (req.url === "/ryandahl.jpg") {
        //读取文件
        fs.readFile("../images/ryandahl.jpg", function(err, data){
            //设置响应头
            res.writeHead(200, {
                "Content-type":"image/jpeg"
            });
            //结束响应
            res.end(data);
        })
    } else if (req.url === "/style.css") {
        //读取文件
        fs.readFile("./style.css", function(err, data){
            //设置响应头
            res.writeHead(200, {
                "Content-type":"text/css"
            });

            //结束响应
            res.end(data);
        })
    } else {
        //设置响应头
        res.writeHead(404, {
            "Content-type":"text/html;charset=utf-8"
        });

        //结束响应
        res.end("<h1>404 您访问的页面不存在</h1>");
    }




}).listen(3000, function(){
    console.log("HTTP Server is running on 3000");
})
