//创建一个HTTP服务， 接收用户的响应

// 引入模块
let http = require("http");

let server = http.createServer(function(req, res){
    // req 表示 请求
    // res 表示 响应

    //设置响应头
    res.writeHead(200, {
        "Content-type":"text/html;charset=utf-8"
    })

    //结束响应
    res.end("<h1>Hello World 你好啊啊啊</h1>");
});

//监听端口
server.listen(3000,function(){
    console.log("Http Server running on port 3000");
});