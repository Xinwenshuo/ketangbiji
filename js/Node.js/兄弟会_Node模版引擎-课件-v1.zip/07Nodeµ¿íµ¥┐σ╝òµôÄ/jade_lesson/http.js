//导入模块
const http = require('http');
const jade = require('jade');

//创建http服务
http.createServer((req, res) => {

    if (req.url === '/favicon.ico') {
        return;
    }

    //定义数据
    const data = {
        title: 'jade 模板引擎',
        content: 'jade 模板引擎 真他妈的奇葩',
        dataList: ['诸葛亮','刘备','曹操','司马懿','孙权']
    };

    //渲染模板
    jade.renderFile('./main.jade', data, (err, html) => {
        if (err) throw err;
        res.writeHead(200, {'content-type':'text/html;charset=utf8'});
        res.end(html);
    })

}).listen(8080, () => {
   console.log('http服务已经启动 端口号8080');
});