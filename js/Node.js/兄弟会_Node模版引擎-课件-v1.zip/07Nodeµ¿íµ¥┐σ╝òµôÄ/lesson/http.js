//导入模块
const http = require('http');
const fs = require('fs');


//创建服务
http.createServer((req, res) => {
    if (req.url === '/favicon.ico') {
        return;
    }

    fs.readFile('./index.html', (err, htmlData) => {
        if (err) throw err;

        //读取文件中内容 (数据库操作)
        fs.readFile('./data.txt', (err, data) => {
            if (err) throw err;
            let nameList = data.toString().split('\r\n');

            //替换模板内容
            let template = htmlData.toString().replace('<%=$name1%>', nameList[0])
                .replace('<%=$name2%>', nameList[1])
                .replace('<%=$name3%>', nameList[2])
                .replace('<%=$name4%>', nameList[3]);

            //做出响应
            res.writeHead(200, {'content-type':'text/html;charset=utf8'});
            res.end(template);
        });



    });



}).listen(8080, () => {
    console.log('http server is runing on port 8080');
})