//导入模块
const http = require('http');
const ejs = require('ejs');

//创建HTTP 服务
http.createServer((req, res) => {

    if (req.url === '/favicon.ico') {
        return false;
    }

    //第一种用法， 直接替换字符串
    //const html = ejs.render('大扎好，我系<%=name%>, 系兄弟就来<%=active%>', {name:'渣渣辉',active:'啃我'});

    //第二种方式
    //const template =  ejs.compile('大扎好，我系<%=name%>, 系兄弟就来<%=active%>');
    //const html = template({name:'古天乐', active:'砍我'});

    //修改定界符  全局方式
    ejs.delimiter = '?';


    //推荐的方式
    let data = {
        title:'我的网站',
        content:'锄禾日当午',
        message: '<h2>日照香炉生紫烟</h2>',
        dataList: [
                {title:'金正恩今天早上打了个喷嚏', date: '2018-09-14', isHot:true},
                {title:'金正日今天早上打了个喷嚏', date: '2018-09-14'},
                {title:'金正月今天早上打了个喷嚏', date: '2018-09-14'},
                {title:'金正太阳今天早上打了个喷嚏', date: '2018-09-14', isHot:true},
                {title:'金正正今天早上打了个喷嚏', date: '2018-09-14'},
                {title:'金正负今天早上打了个喷嚏', date: '2018-09-14'},
                {title:'金负恩今天早上打了个喷嚏', date: '2018-09-14'},
                {title:'金正不恩今天早上打了个喷嚏', date: '2018-09-14'}
            ]
    };
    ejs.renderFile('template/index.ejs', data, {delimiter: '%'}, (err, html) => {
        if (err) throw err;
        res.writeHead(200, {'content-type':'text/html;charset=utf8'});
        res.end(html);
    });

}).listen(8080, () => {
    console.log('http server is running on port 8080');
})


