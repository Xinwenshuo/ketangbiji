
//结束进程
//process.exit(100);

console.log(process.pid);
console.log(process.title);
console.log(process.argv);
console.log(process.argv0);
console.log(process.env);
console.log(process.execPath);
console.log(process.arch);
console.log(process.versions);
console.log(process.platform);
console.log(process.cwd());
console.log(process.memoryUsage());

console.log(a + b);

/*
//开启异步操作
setTimeout(function(){

}, 100000);*/
