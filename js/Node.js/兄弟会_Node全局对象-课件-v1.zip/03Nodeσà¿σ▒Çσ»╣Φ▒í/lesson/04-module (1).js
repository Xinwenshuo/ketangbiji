//module 对象

// requrie() 返回的是 模块中导出的内容
const myModule = require('./01-module');
const figlet = require('figlet');

//判断当前文件是否是 直接node运行的文件
console.log(require.main === module);

console.log(module.children[1]);

console.log(module.filename === __filename);

console.log(module.paths);