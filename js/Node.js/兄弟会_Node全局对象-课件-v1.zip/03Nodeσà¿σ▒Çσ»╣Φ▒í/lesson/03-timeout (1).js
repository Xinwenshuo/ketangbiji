
//异步执行 立即执行
let myImmediate = setImmediate(function(){
    console.log('immediate');
})

setTimeout(function(name){
    console.log(name);
}, 1000, "lili");

console.log("OK");

clearImmediate(myImmediate);