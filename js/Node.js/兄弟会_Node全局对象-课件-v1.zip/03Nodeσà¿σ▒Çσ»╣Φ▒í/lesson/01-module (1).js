console.log(__filename);
console.log(require.main === module);