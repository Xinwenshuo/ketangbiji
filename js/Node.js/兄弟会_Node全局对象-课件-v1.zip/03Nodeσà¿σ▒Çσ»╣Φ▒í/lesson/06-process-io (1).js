//输出流
/*
process.stdout.write("OK");
process.stdout.write("OK");
process.stdout.write("OK");

//输入流
process.stdin.on('data', function(chunk){
    console.log('用户输入：'+chunk);
})
*/

let a;
let b;

process.stdout.write("请输入a的值 : ");

process.stdin.on('data', function(chunk){
    if (!a) {
        a = Number(chunk);
        process.stdout.write('请输入b的值 : ');
    } else {
        b = Number(chunk);
        process.stdout.write("a和b的和是 ： "+(a + b));
    }

})

