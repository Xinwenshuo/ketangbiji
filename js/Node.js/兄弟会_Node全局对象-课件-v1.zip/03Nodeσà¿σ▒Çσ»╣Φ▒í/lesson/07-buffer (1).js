//创建buffer

//为buffer对象 分配10个长度 每个元素自动填充 0
// buffer的每个元素都是一个字节Byte（8bit）
const buf1 = Buffer.alloc(10);

buf1[0] = 10;
buf1[1] = 250;
buf1[2] = 300;
console.log(buf1);
console.log(buf1.length);
console.log(buf1[1]);


//快速创建
const buf2 = Buffer.from([1,2,260,4]);
console.log(buf2.length);
console.log(buf2);

//utf-8编码
const buf3 = Buffer.from('hello');
console.log(buf3);

const buf4 = Buffer.from('你好', 'utf8');
console.log(buf4);

//直接从内存开辟空间， 10个字节。 没有初始化 （可能会包好旧的数据） 速度比较快
const buf5 = Buffer.allocUnsafe(10);
buf5.fill('a');
console.log(buf5.length);
console.log(buf5);

//拼接buffer
const buf6 = Buffer.concat([buf1, buf2]);
console.log(buf6);


//buffer 输出字符串
console.log(buf1.toString('hex'));
console.log(buf3.toString('utf8'));
console.log(buf4.toString());