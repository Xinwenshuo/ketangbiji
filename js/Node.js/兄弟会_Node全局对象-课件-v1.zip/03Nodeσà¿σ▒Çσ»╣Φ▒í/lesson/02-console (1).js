// global.console
console.log('hello', '同志');
console.log('hello %s,come on %d %i %f over', 'lili', 100, 300.01, 100.12);
console.log('json:%j', {name:'xiaolili'});
console.log({name:'xiaolili'});

// console的方法  计数方法
console.count();
console.count('tag');
console.count();
console.count('tag');
console.count('tag');
console.countReset('tag');
console.count('tag');
console.countReset();
console.count();


//console方法 输出对象
//console.dir(global, {colors: true, depth: 1});
//console.log(global);


//时间 计算一段程序的 运行时间
console.time();
for (let i = 0; i < 1000; i ++) {
    i * 15 + 120 / 34;
}
console.timeEnd();

console.log("团");
console.group();
console.log("一营");
console.group();
console.log('一连');
console.log('二连');
console.log('三连');
console.groupEnd()
console.log('二营');
console.groupEnd();
console.log("炮兵团");

/*console.error("错误");
console.warn("警告");
console.trace("trace");*/



//导入figlet模块
const figlet = require('figlet');

figlet("you are SB", function(err, data){
    console.log(data);
});

console.log('OK');


