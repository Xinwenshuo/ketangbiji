console.log(global);

console.log(__filename);
console.log(__dirname);

//导入 01-module.js
require('./01-module');


console.log(global.__filename);