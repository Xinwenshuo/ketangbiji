//导入模块
const http = require('http');
const fs = require('fs');
const {URL} = require('url');
const querystring = require('querystring');
const path = require('path');
const formidable = require('formidable');
const uuid = require('uuid/v1');


//创建服务
http.createServer((req, res) => {
    const url = new URL(req.url, 'http://'+req.headers.hostname);
    //判断路径
    switch(url.pathname) {
        case '/getForm':
            fs.readFile('./get-form.html', (err, data) => {
                if (err) throw err;


                res.writeHead(200, {
                    'Content-type':'text/html;charset=utf8'
                });
                res.end(data);

            });
            break;

        case '/doget':
            let message = `${url.searchParams.get('name')} : ${url.searchParams.getAll('likes').join(',')} \r\n\r\n`;
            fs.writeFile('./get.txt', message, {
                encoding:'utf8',
                flag: 'a'
            }, (err) => {
                if (err) throw err;
                res.writeHead(200, {'Content-type':'text/html;charset=utf8'});
                res.end('表单提交成功')
            });
            break;

        case '/postForm':
            fs.readFile('./post-form.html', (err, data) => {
                if (err) throw err;
                res.writeHead(200, {
                    'Content-type':'text/html;charset=utf8'
                });
                res.end(data);
            })
            break;

        case '/dopost':
            res.writeHead(200, {
                'Content-type':'text/html;charset=utf8'
            });
            let params = '';
            req.on('data', (chunk) => {
                params += chunk;
            });


            req.on('end', () => {
                let paramsData = querystring.parse(params);
                let message = `姓名：${paramsData.name}\r\n
               爱好：${paramsData.likes.join(',')}\r\n
               自我介绍： ${paramsData.info} \r\n\r\n\r\n             
                `;
                fs.writeFile('./post.txt', message, {
                    encoding:'utf8',
                    flag:'a'
                }, (err) => {
                    if (err) throw err;
                    res.writeHead(200, {
                        'Content-type':'text/html;charset=utf8'
                    });
                    res.end('post数据提交成功');
                })
            })

            break;

        case '/uploadForm':
            fs.readFile('./file-form.html', (err, data) => {
                if (err) throw err;
                res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                res.end(data);
            })
            break;

        case '/upload':
            //实例化
            const form = new formidable.IncomingForm({
                uploadDir: './uploads',
                keepExtensions: true,
                //maxFileSize: 2 * 1024 * 1024
            });
            let fields = {likes:[]};

            form.on('field', (name, value) => {
                if (name === 'likes') {
                    fields.likes.push(value)
                } else {
                    fields[name] = value;
                }
            }) ;

            form.on('file', (field, file) => {
                //console.log(field, file);
                //重新命名
                fs.rename(file.path, path.join(form.uploadDir, `${uuid()}.${path.extname(file.path)}`), () => {

                });
            });

            form.on('end', () => {
                console.log(fields);
            });

            //事件
            form.on('error', (err) => {
                res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                res.end(`图片上传失败：`+err.message);
            });



            //解析 请求体
            form.parse(req, (err, fields, files) => {
                if (err) {
                    return;
                }
               // console.log(files);
                //修改文件名
               // fs.renameSync(files.pic.path, path.join(form.uploadDir, `${uuid()}.${path.extname(files.pic.path)}`));
                res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                res.end('文件上传成功'); //结束响应
            });

            break;

        default:
            res.writeHead(404, {
                'Content-type':'text/html;charset=utf8'
            });
            res.end('<h1>404  Not Found</h1>')
    }

}).listen(8080, () => {
    console.log('http server is running on port 8080');
})
