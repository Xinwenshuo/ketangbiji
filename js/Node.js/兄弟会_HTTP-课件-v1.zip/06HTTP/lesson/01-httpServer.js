//导入模块
const http = require('http');

console.log(http.METHODS);

//创建服务
const server = http.createServer((req, res) => {
    res.writeHeader(200, {
        'Content-type':'text/html;charset=utf8'
    });

    for (let attr in req.headers) {
        res.write(`<p>${attr} : ${req.headers[attr]}</p>`);
    }

    //console.log(req.rawHeaders);
    res.write('<hr>');
    res.write(`<p>HTTP的版本号：${req.httpVersion}</p>`);
    res.write(`<p>请求方法：${req.method}</p>`);
    res.write(`<p>请求地址：${req.url}</p>`);

    res.end();
});

server.listen(4000, () => {
    console.log('http server is running on port 4000');
});