//导入模块
const http = require('http');

//创建服务
http.createServer((req, res) => {

    //设置响应头
    res.writeHead(200, {
        'content-type':'text/html;charset=utf8'
    });

    //结束响应
    res.end('hello world');

}).listen(4000, () => {
    console.log('http server is running on port 4000');
});