//导入模块
const http = require('http');
const fs = require('fs');

//创建服务
http.createServer((req, res) => {
    //获取 文件信息
    fs.stat('./index.html', (err, stat) => {
        if (err) throw err;
        //获取最后一次修改时间
        let lastModifiedDate = stat.mtime.toUTCString();
        let ifModifiedSince = req.headers['if-modified-since'];

        //判断 浏览器端 缓存是否过期
        if (ifModifiedSince &&  lastModifiedDate === ifModifiedSince) {
            res.writeHead(304, 'Not Modified');
            res.end();
            return;
        }

        //读取文件;
        fs.readFile('./index.html', (err, data) => {
            if (err) throw err;
            res.writeHead(200, 'OK', {
                'last-modified':lastModifiedDate
            });
            res.end(data);
        })

    });



}).listen(4000, () => {
    console.log('http server is running on port 4000');
})
