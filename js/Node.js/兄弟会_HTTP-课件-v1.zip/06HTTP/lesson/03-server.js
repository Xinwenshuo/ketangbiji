//导入模块
const http = require('http');

//创建服务
const server = http.createServer();

//server 事件
server.on('request', (req, res) => {


    res.end('hello');

    server.close(); //关闭服务
});

server.on('close', () => {
    console.log('服务器关闭');
})



//监听
server.listen(8080, () => {
    console.log('http server is running on port 8080');
    console.log(server.listening);
})

//console.log(server.maxHeadersCount);