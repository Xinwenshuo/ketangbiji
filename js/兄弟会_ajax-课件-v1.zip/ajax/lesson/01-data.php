<?php
echo "Hello PHP ".date("Y-m-d H:i:s");