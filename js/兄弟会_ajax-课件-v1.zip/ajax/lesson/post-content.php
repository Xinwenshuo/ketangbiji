<?php
//设置字符集编码
header("Content-type:text/html;charset=utf-8");

//判断是否传值
if (empty($_POST['name']) || empty($_POST['message'])) {
	exit("内容不能为空");
}

//获取 GET 提交的内容
$name = $_POST['name'];
$message = $_POST['message'];


//将获取的内容写入文件
$content = $name."(".date("H:i:s").") : \r\n".$message."\r\n\r\n";
file_put_contents("post_content.txt", $content, FILE_APPEND);

echo "内容写入成功";