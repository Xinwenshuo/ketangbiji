<?php
sleep(2);
echo "Hello, PHP";