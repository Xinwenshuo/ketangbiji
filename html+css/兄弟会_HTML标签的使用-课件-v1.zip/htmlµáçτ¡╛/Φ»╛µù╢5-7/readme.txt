回顾
========================
html基础
	html   超文本标记语言    
	html的组成   标签 (单标签 双标签)   属性 
	书写格式  
	html实体   &nbsp;   &lt;   &gt;    &amp;      &quot;    &copy;   &times;
   	注释    <!-- 注释 -->
	
主体标签
		<!doctype html>
		<html>
		<head>
		<body>
	head 元素	
		<meta> 属性  charset    name  http-equiv     content
		<title>
		<link>   
		<base>
		<script>
		<style>
			
格式标签
		<br>
		<hr>	分隔线  
		<p>  段落 
		<pre>		原样输出
		<ul>		无序列表
		<ol>		有序列表
		<li>			列表
		<hn>       标题
 		
	
	





HTML标签
===========================
1. 超链接
	1.1 路径问题
		相对路径
			./  当前目录下   
			../  上一个目录   ../../
		绝对路径
			http://   开头
		相对于站点根目录的相对路径
			/ 开头
	1.2 属性
		title
		target   :   _blank   _self    _parent   _top
		href     url   相对路径   绝对路径
		download
	1.3 其他功能
		① 跳转  :  url
		② 邮件  :  email:邮箱地址

2. 锚点
	<a name=""></a>


3. 图像
		3.1 img标签
			属性  src   alt   title  width   height   border  ismap    usemap(配合map标签)
			图片格式:    jpg   png    gif   	.....
		3.2 map
			id
			name
		3.3 area
			shape  制定形状   rect  circle   poly
			coords	坐标
			href
			target
			alt
			

扩展知识

============================
汉字编码:
	gb2312  
	gbk  (汉语  日语   韩语)
	utf-8 (万国码)
	
搜索引擎:
	baidu   google   搜狗   搜狐   360  ....
	
	
	
作业
=========================
整理笔记
课堂代码 2 遍
使用 img map area 锚点 实现 效果
	
	
	