HTML
========================
一 介绍HTML
	1. URL
		统一资源定位符
		http://www.w3school.com.cn/b.php
		http://  协议
		www.w3school.com.cn  域名 (对应ip地址)
		b.php  文件名
		
	2. HTML标签(元素)
		单标签  双标签
		
	3. 属性
		用来修饰标签
		
	4. 颜色
		RGB (Red  Green  Blue)  计算机三原色
		0- ff  0-ff  0-ff
		英文单词
	
	5. 注释
		<!-- 注释   -->
		
	6. HTML实体	
		&lt;      &gt;    &amp;   &quot;   &copy;   &nbsp;   &times;
		
		
二 结构标签
	html
	body
	head

三 head 标签
	title
	meta
	base
	link
	style
	script
四 格式排版标签
	br
	hr	
	p
	pre
	ul
	ol
	li
	hn (h1-6)
	center
	
	
老的HTML CSS2
HTML5  CSS3


作业
================================
整理笔记
敲代码:  2.html     5.html  (3遍)
做一个页面: 介绍事物的网页 使用今天所学习的标签
	 

