HTML 
	制作网页的语言
	超文本标记语言

	写一个HTML的文件
		文档头
		<!doctype html>

		HTML标签
		<html>
			头部
			<head>
				都是要告诉浏览器的信息：文件的编码、文件的关键字、描述、作者等相关的信息
			</head>
			主体
			<body>
				显示在浏览器的部分
			</body>
		</html>