// 定义JS
alert('再次欢迎!');