回顾
==========================
1. 文本标签
	<em>  
	<strong>
	<code>
	<cite>
	<var>
	<dfn>
	<samp>
	<b>
	<i>
	<kbd>
	<sup>
	<sub>
	<small> 旁注
	<abbr title="全称">
	<bdo dir="">
	<ins datetime="1989-07-01">
	<del>
	<q>
	<blockquote>
	<address>
	
	
	
2. 表格标签
	<table>   border    width   height    cellspacing  cellpadding   bgcolor   background   align
	<tr>		height	  align(left  center   right)    valign(top  middle bottom)  bgcolor
	<td>       width  height  align   valign   bgcolor    rowspan    colspan
	<th>       width  height  align   valign   bgcolor    rowspan    colspan
	<caption>   标题
	<thead>		 align   height  valign   bgcolor
	<tbody>
	<tfoot>
	<colgroup>   设置宽度  背景颜色
	<col>
	
	
3. 表单标签
	<form>	action=""   method="get|post"    target=""    
	<input>   type=""    name=""   value=""
			文本框:     <input type="text"  name=""  value="">    readonly   size  maxlength
			密码框:     <input type="password"  name=""  value="">		readonly  size   maxlength
			单选框:     <input type="radio"  name=""  value="值">    checked	
			复选框:		<input type="checkbox" name="" value="值">  checked
			提交按钮:  <input type="submit" value="按钮内容" >
			重置按钮:  <input type="reset" value="按钮内容" >
			普通按钮:  <input type="button" value="按钮内容" >
			图片按钮:  <input type="image" src="图片地址" alt="">  提交按钮
			隐藏域:		 <input type="hidden" name="" value="">
			
	<select>   下拉列表
			属性 :  name=""
			配合option
	<option>	下拉选项
			属性 :  value      selected
	<optgroup>
			给下拉选项分组
	<textarea>
			文本域
			name=""   rows=""    cols=""   readonly
	<button>
			按钮(默认是提交按钮)
			type="submit|button"    
	<fieldset>
	<legend>
	所有的表单控件都具有的属性
	disabled
	enabled
	
	
HTML标签
=============================
1. 框架 分帧
	<iframe></iframe>
	<frameset>
	<frame>
	<noframes>
2. 程序	
	<script>
	<noscript>
	<object data="">
	<param>
	
	
作业
==================================
1. 课堂代码 2 遍
2. 整理笔记
3. 分帧
	左边导航
		简历
		table form 页面
		图片映射
		


	
	
	
	
	
