回顾
==========================================
超链接
	<a></a>
	href=""
	target=""   _self   _blank
	title
	alt
地址url:
	相对路径  ./    ../
	绝对路径  http://
	
锚点
	<a name=""></a>
	跟超链接配合
	
图片
	<img>
	src=""
	alt=""
	title=""
	width=""
	height=""
	border
	

图片映射
	<img usemap="#mymap">
	<map id="mymap" name="mymap">
		<area>
			shape="rect|circle|poly"
			coords=""
			href
			alt
			title
			......
	</map>
	
	


HTML标签
===========================================
1. 文本标签
	<em>			强调   !!!!!!
	<strong>		更强调  !!!!!
	<cite>			引用 书籍名\电影名\音乐名....   !!!!
	<dfn>			项目
	<samp>		不常用  强调
	<code>       代码  !!!!!
	<kbd>			键盘输入
	<bdo>			改变文字输入方向
	<ins>			添加的
	<del>			已删除的
	<abbr>		定义缩写   !!!!
	<var>			变量名  !!!!
	<small>		小型字 副标题  ！！！
	<sub>			下标　！！！
	<sup>			上标　　！！！
	<b>				加粗 强调
	<i>				斜体  科技术语
	<u>				下划线  拼写错误的
	<q>				短引用
	<blockquote>  长引用
	<address>  地址　！！！
	
2. 表格
	2.1 基本概念
		行   单元格
	2.2 标签
		<table>   属性  border   width   height   cellspacing  cellpadding
		<tr>   tableRow	 行    height   bgcolor    align   valign
		<td>  tableCell     单元格		width  height   align  valign   bgcolor   rowspan  colspan
		<caption>  标题 
		<th>	表头 tableHead  等同于 单元格
		<thead>
		<tbody>
		<tfoot>
		<colgroup> !
		<col> !!!		修改指定的列(宽度 背景颜色)
		
3. 表单
	1. form
		属性:  action   method
	2. input 元素
		属性 type:   值:  text    password      radio    checkbox    file
								 submit   reset     button    image
				name
		        value		表示input的值  
				size          input的尺寸
				maxlength  input最大输入长度
				readonly   只读
				disabled   不可用
	3. button元素
		type属性 submit(默认) button
	4. select元素		属性 name
	5. option元素		属性  value   selected
	6. optgroup元素	  把option进行分组
	7. textarea元素  属性  name   rows  cols
	8. fieldset
	9. legend
	
	
	
作业
==========================================
代码 2 遍
总结笔记
总结所有的标签: 单标签  双标签
总结文本标签 找出   加粗   倾斜
定义注册页面, 用户名 , 密码 确认密码   性别   学历      爱好   提交按钮, 使用表格和表单
使用表格 做一个 简历 
							

		
		
		