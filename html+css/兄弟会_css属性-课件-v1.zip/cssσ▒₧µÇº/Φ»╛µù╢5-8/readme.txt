回顾
=================================
1. CSS基础
	1. 如何去使用CSS
		① style属性   <p style="css...">
		② <style>标签中
		③ <link> 引入外部的css
		④ import url()  引入css
	2. CSS的组成
		选择器{
			属性:值;
			属性:值;
		}
	3. 注释
		/* */
	4. CSS的写法
		扩展  嵌套  紧凑  压缩
	5. CSS的单位
		长度单位:   px   百分比  em   |  pt   cm ...
		颜色单位:  英文单词   rgb(0-255,0-255,0-255) rgb(百分比,百分比,百分比)   16进制  #()
		URL:
		
		
		
2. CSS的选择器
	① html元素选择器 (标签选择器) div{}
	② class选择器    .类名{}  <p class="item list">
	③ id选择器        #id名
	④ 全局选择器    *
	⑤ 关联选择器
		selecter selcter        .list li
		selecter>selcter        .list>li
	⑥ 组合选择器
		selecter,seldcter,seldcter
		标签名.类名 		
	⑦ 伪类选择器
		:link
		:hover
		:active
		:visited
		
3. CSS的背景属性
	background:<color> <image> <repeat> <attachment> <position>
	backgorund-color:
	background-image:
	background-repeate: repeate|no-repeat|repeat-x|repeat-y
	background-attachment: scroll|fixed
	background-position:left|center|right top|center|bottom   
	
	
width
height
border


CSS常见的属性
==============================================
1. 字体属性
	font-family
	font-size
	font-style 	  norml | italic | oblique
	font-weight   normal|lighter|bold|bolder
	font-variant   normal|small-caps
	font: <style> <weight> <variant> font-size font-family
	color:
2. 文本属性
	letter-spacing
	word-spacing
	text-decoration   none | underline | overline | line-through
	text-align  left | center | right
	vertical-align  baseline ....
	line-height
	text-indent
3. 边框属性
	border:width style color
	border-color
	border-width
	border-style  solid | dotted | dashed 
	border-left....
	......
4. 光标属性
	cursor    default |  move  |  pointer  |  crosshair  | wait  | help | text 
	
5. 列表属性 ul li
	list-style
	list-style-type   disc | circle | square | decimal  ...
	list-style-position    inside  outside
	list-style-iamge   
	
6.  表格属性
	border-collapse   collapase | separate
	border-spacing:  length
	table-layout	: fiexed | auto
	caption-side : top | bottom
	empty-cells:  show | hide
	
	
	
CSS选择器优先级
	
	
	
	
	
作业
================================
1. 课堂代码 2 遍
2. 整理笔记
3. 复习题目    文本标签,   每一个标签举个例子
4. 使用 所学html css 做一个网页 

	
