回顾
=============================
框架和分帧
	<iframe>  src=""  widht=""  height=""  ... 
	<frameset rows=""   cols=""></frameset>  
	<frame> src="" name=""
	<noframes>
程序
	<object data="url"></object>
	<param name="" value="">  给程序设置参数
	<script>
	<noscript>
	



CSS 级联样式表
=============================
1. CSS基础
	1.1 css组成
		  选择器{css属性:值}
	1.2 CSS的使用
		① 在元素中 使用 style属性
        ② 在 <style>元素中 
		③ 使用 link 元素 引入 外部的css
		④ @import url()  必须写在css代码中
	1.3 基础语法
		注释  /*   */
		书写格式: 扩展   嵌套    紧凑   压缩 
	1.4 CSS的单位
		长度单位: 相对单位: px(像素)      百分比       em(倍数)       绝对单位:pt(点)   cm   mm
		颜色单位:   英文字符(red green)     rgb(0-255, 0-255, 0-255) rgb(百分比,百分比,百分比)    16进制

2. CSS选择器
	2.1 HTML元素选择器
	2.2 ID选择器
	2.3 CLASS选择器
	2.4 全局选择器 *
	2.5 关联选择器   
		selected selected
		selected>selected
	2.6 组合选择器
		select,select,select....
		p.item   标签名.类名   标签名#id名
		
3. CSS 常见属性
	3.1 背景属性
		background-color
		background-image
		background-repeate
		background-attachment
		backgorund-position
		backgorund:<color> <url('')> <repeate> <attachment> <position>
		雪碧图 spider  Sprite




		
计算机进制
===============================
10进制:
0 1 2 3 4 5 6 7 8 9 10 11....
0 1 10 11 100 101 110 111 1000
0 1 2 3 4 5 6 7 8 9 a b c d e f 10 11 12


94 = 9*10+4
ff  = 15*16+15 = 255