回顾  CSS属性
===================================
1. 字体属性
	font  font-size  font-style   font-weight    font-variant    font-family
2. 颜色属性
	color
3. 文本属性
	letter-spacing    word-spacing     text-align     text-indent   line-height   text-decoration   vertical-align
4. 边框属性
	border   border-style   border-width   border-color
5. 背景属性
	background  backgorund-color   background-image   background-repeat   background-attachment   background-position
6. 鼠标属性
	cursor
7. 列表属性
	list-style   list-style-type   list-style-image   list-style-position
8. 表格属性
	talbe-layout  border-collapse   border-spacing   empty-cells   caption-side



div+css  布局
====================================
adobe  
1. div元素  和 span元素
	style    id     class   name   title

2. 块级元素(行级元素)和行内元素(内联元素)
	2.1 块级元素
		
		
		常见的块级元素: div    p    h1~h6   table   tr  capion  fieldset  legend     ul   ol    li   hr   br 
									address   blockquote  pre
	2.2 行内元素
	
3. 盒子模型
	任何一个元素都可以是盒子模型
	width  hegiht  内容
	padding			内边距(内补白)
	border				边框
	margin			外边距
	
4. 盒子模型之间的关系
	4.1 document树
		父元素  子元素   后代元素   
	4.2 标准文档流	
	4.3 盒子在标准文档流中的定位
		1. 水平margin   margin-left  margin-right
		2. 垂直margin margin-top  margin-bottom  上下两个盒子的间距是两个盒子最大的margin		
		3. 子元素的margin对父元素的影响
		
5. 浮动
	① 元素设置浮动 (如果没有设置宽度)宽度随内容变化
	② 给行级元素设置浮动,会变成块级元素
	③ 元素设置浮动, margin坍陷 就不存在
	④ 浮动元素 会对后面的元素和父元素产生影响
		clear:both     overflow:hidden;

		