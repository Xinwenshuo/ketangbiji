回顾
============================
1. 定位
	相对定位
		position:relative
		top   left    bottom   right
	绝对定位
		position:absolute
		top   left    bottom   right
		根据最近的已经定位的祖先元素
	固定定位
		position:fixed
	position:static
	层级关系  z-index
		只对定位的元素起作用
	
2. 其他属性
	overflow:  hidden | visible  | scroll  | auto
	overflox-x:
	overflow-y:
	display:block | inline | inline-block  | none
	visibility : hidden | visible
	max-width    min-width
	max-height   min-height
	pdding:
	margin:
	
	
	
	
网页布局
=======================================
1. emmet 插件   
2. 切图
	切图工具:  PS   fireworks
	2.1 ps的设置
		1. 设置默认单位
3. 重置所有的css样式

	


	
		