DIV+CSS布局
====================================
1.  块级元素 和 行级元素
	块级: 独占一行	
			width height  padding  margin
			格式标签\div\table\tr
			
	行级: 与其他公用一行
			width height 无用,   padding 有用  margin 只有水平起作用
			文本标签\链接\图片\span

2.  盒子模型
	2.1 盒子模型大小
		content(width height)
		内边距(padding)
		边框(border)
	2.2 盒子模型位置
		外边距(margin)
	2.3 盒子模型 Document树
		父元素  子元素    后代元素     兄弟元素   前辈元素
	2.4 盒子关系 margin
		1. 水平	margin  
		2.  垂直 margin  margin坍陷
		3.  父元素 子元素 margin
 
3.  浮动
	3.1 属性
		float: left|right|none
		clear: left|right|both
		overflow:hidden|auto|scroll
	3.2 元素设置浮动 特点
		① 脱离了标准文档流
		② 浮动后默认宽度 变成内容宽
		③ 行级元素 浮动 自动转换为 块级元素
	3.3 消除浮动的影响
		① 消除对 后面元素的影响  给后面元素 设置 clear
		② 消除对 父元素的影响  给父元素设置 overflow 或者  给父元素也浮动
	3.4 布局
		
4. 定位
	4.1相对定位
		position:relative; left  top  right  bottom   
		相对于自己原来的位置
	4.2 绝对定位
		position:absolute;  left  top  right  bottom
		根据 最近的一个 已经定位的"祖先元素"去定位, 如果没有定位的祖先元素,根据html元素
	4.3 固定定位
		postion:fixed;   left top  right  bottom
		根据屏幕去定位  
	4.4 z-index 空间位置
		该属性 用于 定位的元素
		
5. 相关属性
	5.1 盒子模型
		display:   inline | block | inline-block | none
		overflow:  hidden|scroll|auto|visible
		overflow-x
		overflow-y
		vilibility: hidden|visible
		float
		clear
	5.2 尺寸
		width
		max-width
		min-width
		height
		max-height
		min-height
	5.3 padding
		padding: 四个方向
		padding: 上下  左右;
		padding: 上 左右 下;
		padding: 上 右 下 左;
	5.4 margin
		同上
		
		
6. 居中
	6.1 水平居中
		① 文字 或 行级元素   给父元素设置 text-align:center
		② 块级元素居中:  给自己 设置 左右margin为auto  设置宽度
	6.2 垂直居中
		① 文字 或 行级元素
			在父元素 设置 line-height 与 height 一样
	6,3 块级元素上下左右居中
		
		
		
	
	
	